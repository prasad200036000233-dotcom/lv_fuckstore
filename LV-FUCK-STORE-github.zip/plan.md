# LV FUCK STORE plan

## Product
A public, responsive video catalog with instant playback and an admin-only content studio. Visitors never need an account. The admin can manage videos, thumbnails, categories, featured placement, metadata, and theme settings.

## Implementation
- React/Vite frontend with a small Express API.
- Server-side email/password admin session using protected `ADMIN_EMAIL` and `ADMIN_PASSWORD` environment values; no credentials in client code.
- Public REST endpoints for catalog/category reads.
- Admin REST endpoints for login/logout and catalog CRUD.
- Durable-ready media fields: video and thumbnail URLs can point to project storage or any approved CDN. Upload controls accept direct URLs today and are structured for storage presign integration.
- GitHub-ready source with `.env.example`, route manifest, build instructions, and a note that secure admin functionality requires a server host rather than GitHub Pages alone.

## Design
Three directions considered: editorial neon cinema (0.07), utility dashboard (0.08), soft creator library (0.06). Chosen: **editorial neon cinema**.

### Design movement
Late-night streaming editorial: a dark theatre-like canvas with acid-lime accents and oversized artwork.

### Core principles
1. Visual-first browsing with large thumbnails and immediate action.
2. Strong contrast and a restrained two-color system.
3. Public catalog stays simple; admin tools feel precise and operational.
4. Every interaction should feel quick and reversible.

### Color philosophy
Near-black surfaces create a cinematic stage; acid lime marks the brand and calls attention to play, featured content, and primary actions. Warm off-white keeps text readable without looking sterile.

### Layout paradigm
A left rail and wide content canvas on desktop, collapsing into a compact top bar on mobile. Editorial shelves break up the page instead of a generic centered dashboard grid.

### Signature elements
- Acid-lime play button and underline marker.
- Thumbnail cards with subtle grain, metadata chips, and hover lift.
- Monogram-style LV mark paired with compact uppercase wordmark.

### Interaction and animation
Fast 160–220ms fades and lifts, no distracting autoplay. Modal player opens with a darkened stage. Theme switching is instant and persistent.

### Typography
Use `Space Grotesk` for headings and `DM Sans` for body/interface copy, with uppercase tracking for labels.

### Brand essence
A sharp, owner-controlled video shelf for people who want content discovery without friction. Personality: direct, nocturnal, curated.

### Brand voice
Headlines: “Play something worth staying up for.”
Microcopy: “No sign-in. Just press play.”

### Wordmark
A compact LV monogram inside a rounded black tile, followed by the wordmark with a lime slash as the signature.

### Signature brand color
Acid lime `#C8FF3D`.
