CREATE TABLE `catalogState` (
	`id` int NOT NULL,
	`payload` text NOT NULL,
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `catalogState_id` PRIMARY KEY(`id`)
);
