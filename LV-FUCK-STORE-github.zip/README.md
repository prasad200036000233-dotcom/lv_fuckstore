# LV FUCK STORE

A responsive public video catalog with a secure admin studio for managing videos, thumbnails, categories, featured placement, and site themes.

## Features

Public browsing requires no visitor sign-in. The `/admin` studio uses a server-side email/password session and lets the owner add, edit, delete, feature, and categorize videos. The interface includes large thumbnail cards, instant playback, search, and light/dark themes.

## Local development

```bash
pnpm install
pnpm dev
```

Set `ADMIN_EMAIL` and `ADMIN_PASSWORD` in the hosting environment. Managed Manus environments keep these as protected project secrets. For a normal GitHub clone, copy `.env.example` to `.env` and set them locally.

## GitHub deployment note

The source is GitHub-ready and can be downloaded as a ZIP or pushed to a repository. Secure admin sessions and server-side content management cannot run on GitHub Pages alone, so deploy the full-stack app to a Node host connected to GitHub. GitHub Pages is suitable only for a public-only static build.

## Media

The admin studio accepts direct video/thumbnail uploads through the server-side project storage presign flow, and also accepts CDN or project-storage URLs. Keep large media out of Git. The application stores stable `/manus-storage/...` addresses rather than binary media in the repository.

## Scripts

`pnpm dev` starts the full-stack preview, `pnpm build` creates the production bundle, `pnpm start` serves it, and `pnpm check` runs TypeScript diagnostics.
