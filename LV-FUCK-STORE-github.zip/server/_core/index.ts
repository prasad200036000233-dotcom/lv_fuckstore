import "dotenv/config";
import express from "express";
import cookieParser from "cookie-parser";
import { createServer } from "http";
import { createExpressMiddleware } from "@trpc/server/adapters/express";
import { registerOAuthRoutes } from "./oauth";
import { publicPlatformScript } from "./publicConfig";
import { appRouter } from "../routers";
import { createContext } from "./context";
import { serveStatic, setupVite } from "./vite";
import { categories, createCategory, createVideo, deleteCategory, deleteVideo, ensureCatalog, isAdmin, login, logout, persistCatalog, updateCategory, updateVideo, videos } from "../catalog";

async function startServer() {
  const app = express();
  const server = createServer(app);
  app.use(cookieParser());
  app.use(express.json({ limit: "50mb" }));
  app.use(express.urlencoded({ limit: "50mb", extended: true }));
  app.get("/api/health", (_req, res) => res.json({ status: "ok" }));
  app.get("/api/platform/config.js", (_req, res) => res.set("Cache-Control", "no-store").type("application/javascript").send(publicPlatformScript()));

  app.get("/api/catalog", async (_req, res) => { await ensureCatalog(); return res.json({ videos, categories }); });
  app.get("/api/admin/me", (req, res) => res.json({ authenticated: isAdmin(req) }));
  app.post("/api/admin/login", (req, res) => login(req, res) ? res.json({ ok: true }) : res.status(401).json({ error: "Invalid admin credentials" }));
  app.post("/api/admin/logout", (_req, res) => { logout(res); res.json({ ok: true }); });
  app.put("/api/admin/upload", express.raw({ type: ["video/*", "image/*", "application/octet-stream"], limit: "250mb" }), async (req, res) => {
    if (!isAdmin(req)) return res.status(403).json({ error: "Admin only" });
    const originalName = String(req.headers["x-file-name"] || "upload.bin").replace(/[^a-zA-Z0-9._-]/g, "-");
    const key = `lv-media/${Date.now()}-${originalName}`;
    const base = process.env.MANUS_API_URL;
    const apiKey = process.env.MANUS_API_KEY;
    if (!base || !apiKey) return res.status(503).json({ error: "Object storage is not configured" });
    try {
      const presign = await fetch(`${base}/v1/storage/presign/put?path=${encodeURIComponent(key)}`, { headers: { Authorization: `Bearer ${apiKey}` } });
      const presignBody = await presign.json() as { url?: string; error?: string };
      if (!presign.ok || !presignBody.url) return res.status(502).json({ error: presignBody.error || "Could not prepare upload" });
      const upload = await fetch(presignBody.url, { method: "PUT", headers: { "Content-Type": String(req.headers["content-type"] || "application/octet-stream") }, body: new Uint8Array(req.body as Buffer) });
      if (!upload.ok) return res.status(502).json({ error: "Could not upload file" });
      return res.json({ url: `/manus-storage/${key}`, key });
    } catch { return res.status(502).json({ error: "Upload service unavailable" }); }
  });
  app.post("/api/admin/videos", async (req, res) => { if (!isAdmin(req)) return res.status(403).json({ error: "Admin only" }); return res.json(await createVideo(req.body)); });
  app.patch("/api/admin/videos/:id", async (req, res) => { if (!isAdmin(req)) return res.status(403).json({ error: "Admin only" }); const item = await updateVideo(req.params.id, req.body); return item ? res.json(item) : res.status(404).json({ error: "Video not found" }); });
  app.delete("/api/admin/videos/:id", async (req, res) => { if (!isAdmin(req)) return res.status(403).json({ error: "Admin only" }); return (await deleteVideo(req.params.id)) ? res.json({ ok: true }) : res.status(404).json({ error: "Video not found" }); });
  app.post("/api/admin/categories", async (req, res) => { if (!isAdmin(req)) return res.status(403).json({ error: "Admin only" }); const name = String(req.body?.name || "").trim(); if (!name) return res.status(400).json({ error: "Name required" }); return res.json(await createCategory(name)); });
  app.patch("/api/admin/categories/:id", async (req, res) => { if (!isAdmin(req)) return res.status(403).json({ error: "Admin only" }); const item = await updateCategory(req.params.id, String(req.body?.name || "")); return item ? res.json(item) : res.status(404).json({ error: "Category not found" }); });
  app.delete("/api/admin/categories/:id", async (req, res) => { if (!isAdmin(req)) return res.status(403).json({ error: "Admin only" }); return (await deleteCategory(req.params.id)) ? res.json({ ok: true }) : res.status(400).json({ error: "Default category cannot be deleted" }); });

  registerOAuthRoutes(app);
  app.use("/api/trpc", createExpressMiddleware({ router: appRouter, createContext }));
  if (process.env.NODE_ENV === "development") await setupVite(app, server); else serveStatic(app);
  const port = Number(process.env.PORT || "3000");
  server.on("error", error => { console.error("Server failed:", error.message); process.exit(1); });
  await ensureCatalog();
  await persistCatalog();
  server.listen(port, "0.0.0.0", () => console.log(`Server listening on port ${port}`));
}
startServer().catch(error => { console.error(error); process.exit(1); });
