import crypto from "node:crypto";
import type { Request, Response } from "express";
import { eq } from "drizzle-orm";
import { catalogState } from "../drizzle/schema";
import { getDb } from "./db";

export type Category = { id: string; name: string; order: number };
export type Video = { id: string; title: string; description: string; duration: string; categoryId: string; thumbnailUrl: string; videoUrl: string; featured: boolean; createdAt: string };
const demoThumbs = [
  "https://images.unsplash.com/photo-1519608487953-e999c86e7455?auto=format&fit=crop&w=1200&q=80",
  "https://images.unsplash.com/photo-1485846234645-a62644f84728?auto=format&fit=crop&w=1200&q=80",
  "https://images.unsplash.com/photo-1536440136628-849c177e76a1?auto=format&fit=crop&w=1200&q=80",
  "https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?auto=format&fit=crop&w=1200&q=80",
];
const sampleVideo = "https://storage.googleapis.com/coverr-main/mp4/Mt_Baker.mp4";
function seedCategories(): Category[] { return [{ id: "all", name: "All videos", order: 0 }, { id: "new", name: "New drops", order: 1 }, { id: "featured", name: "Featured", order: 2 }]; }
function seedVideos(): Video[] { return [
  { id: "v1", title: "After Hours / Vol. 01", description: "A late-night cut from the LV archive.", duration: "08:42", categoryId: "featured", thumbnailUrl: demoThumbs[0], videoUrl: sampleVideo, featured: true, createdAt: new Date().toISOString() },
  { id: "v2", title: "Neon Room Sessions", description: "Low light, high energy, one continuous take.", duration: "12:18", categoryId: "new", thumbnailUrl: demoThumbs[1], videoUrl: sampleVideo, featured: true, createdAt: new Date().toISOString() },
  { id: "v3", title: "The Quiet Cut", description: "A slower edit for the midnight shelf.", duration: "06:24", categoryId: "new", thumbnailUrl: demoThumbs[2], videoUrl: sampleVideo, featured: false, createdAt: new Date().toISOString() },
  { id: "v4", title: "Backroom Frequency", description: "Recorded live, edited sharp.", duration: "15:07", categoryId: "all", thumbnailUrl: demoThumbs[3], videoUrl: sampleVideo, featured: false, createdAt: new Date().toISOString() },
  { id: "v5", title: "Midnight Drive", description: "A long-form cut from the night shift.", duration: "09:31", categoryId: "new", thumbnailUrl: "https://images.unsplash.com/photo-1519501025264-65ba15a82390?auto=format&fit=crop&w=1200&q=80", videoUrl: sampleVideo, featured: false, createdAt: new Date().toISOString() },
  { id: "v6", title: "Studio Take 05", description: "Behind the edit, in one uninterrupted take.", duration: "11:02", categoryId: "all", thumbnailUrl: "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?auto=format&fit=crop&w=1200&q=80", videoUrl: sampleVideo, featured: false, createdAt: new Date().toISOString() },
  { id: "v7", title: "City Lights / Cut Two", description: "The city after dark, framed in motion.", duration: "07:48", categoryId: "featured", thumbnailUrl: "https://images.unsplash.com/photo-1492684223066-81342ee5ff30?auto=format&fit=crop&w=1200&q=80", videoUrl: sampleVideo, featured: true, createdAt: new Date().toISOString() },
  { id: "v8", title: "Open Set Diaries", description: "A raw cut from the open set diaries.", duration: "13:16", categoryId: "all", thumbnailUrl: "https://images.unsplash.com/photo-1485846234645-a62644f84728?auto=format&fit=crop&w=1200&q=80", videoUrl: sampleVideo, featured: false, createdAt: new Date().toISOString() },
  { id: "v9", title: "Low Light / High Volume", description: "A darker shelf pick with a bright finish.", duration: "10:27", categoryId: "new", thumbnailUrl: "https://images.unsplash.com/photo-1501386761578-eac5c94b800a?auto=format&fit=crop&w=1200&q=80", videoUrl: sampleVideo, featured: false, createdAt: new Date().toISOString() },
  { id: "v10", title: "The Long Take", description: "No cuts, no rush, just press play.", duration: "18:40", categoryId: "all", thumbnailUrl: "https://images.unsplash.com/photo-1514525253161-7a46d19cd819?auto=format&fit=crop&w=1200&q=80", videoUrl: sampleVideo, featured: false, createdAt: new Date().toISOString() },
  { id: "v11", title: "Afterparty Archive", description: "A late entry from the archive room.", duration: "14:22", categoryId: "featured", thumbnailUrl: "https://images.unsplash.com/photo-1516450360452-9312f5e86fc7?auto=format&fit=crop&w=1200&q=80", videoUrl: sampleVideo, featured: true, createdAt: new Date().toISOString() },
  { id: "v12", title: "Final Frame", description: "The final frame is always worth staying for.", duration: "08:09", categoryId: "all", thumbnailUrl: "https://images.unsplash.com/photo-1506157786151-b8491531f063?auto=format&fit=crop&w=1200&q=80", videoUrl: sampleVideo, featured: false, createdAt: new Date().toISOString() },
]; }
export const categories: Category[] = [];
export const videos: Video[] = [];
let loaded = false;

export async function ensureCatalog() {
  if (loaded) return;
  const db = await getDb();
  if (db) {
    try {
      const rows = await db.select().from(catalogState).where(eq(catalogState.id, 1)).limit(1);
      const row = rows[0];
      if (row?.payload) {
        const parsed = JSON.parse(row.payload) as { categories: Category[]; videos: Video[] };
        categories.splice(0, categories.length, ...(parsed.categories || []));
        videos.splice(0, videos.length, ...(parsed.videos || []));
      }
    } catch (error) { console.warn("[Catalog] Could not load database state; using seed data", error); }
  }
  if (!categories.length) categories.push(...seedCategories());
  const seed = seedVideos();
  if (!videos.length) videos.push(...seed);
  else if (videos.length < seed.length) videos.push(...seed.slice(videos.length));
  loaded = true;
  await persistCatalog();
}

export async function persistCatalog() {
  const db = await getDb();
  if (!db) return;
  try { await db.insert(catalogState).values({ id: 1, payload: JSON.stringify({ categories, videos }) }).onDuplicateKeyUpdate({ set: { payload: JSON.stringify({ categories, videos }), updatedAt: new Date() } }); }
  catch (error) { console.warn("[Catalog] Could not persist database state", error); }
}

function id() { return crypto.randomUUID(); }
export function isAdmin(req: Request) { return req.cookies?.lv_admin_session === signedSession(); }
function signedSession() { const email = process.env.ADMIN_EMAIL || ""; const password = process.env.ADMIN_PASSWORD || ""; return crypto.createHmac("sha256", password || "lv-fallback").update(email || "lv-admin").digest("hex"); }
export function login(req: Request, res: Response) { const { email, password } = req.body as { email?: string; password?: string }; const expectedEmail = process.env.ADMIN_EMAIL || ""; const expectedPassword = process.env.ADMIN_PASSWORD || ""; if (!expectedEmail || !expectedPassword || email !== expectedEmail || password !== expectedPassword) return false; res.cookie("lv_admin_session", signedSession(), { httpOnly: true, sameSite: "none", secure: true, maxAge: 1000 * 60 * 60 * 24 * 7 }); return true; }
export function logout(res: Response) { res.clearCookie("lv_admin_session", { httpOnly: true, sameSite: "none", secure: true }); }
export async function createVideo(input: Partial<Video>) { await ensureCatalog(); const item: Video = { id: id(), title: input.title || "Untitled video", description: input.description || "", duration: input.duration || "00:00", categoryId: input.categoryId || "all", thumbnailUrl: input.thumbnailUrl || demoThumbs[0], videoUrl: input.videoUrl || sampleVideo, featured: Boolean(input.featured), createdAt: new Date().toISOString() }; videos.unshift(item); await persistCatalog(); return item; }
export async function updateVideo(videoId: string, input: Partial<Video>) { await ensureCatalog(); const item = videos.find(v => v.id === videoId); if (!item) return null; Object.assign(item, { ...input, id: item.id, createdAt: item.createdAt }); await persistCatalog(); return item; }
export async function deleteVideo(videoId: string) { await ensureCatalog(); const index = videos.findIndex(v => v.id === videoId); if (index < 0) return false; videos.splice(index, 1); await persistCatalog(); return true; }
export async function createCategory(name: string) { await ensureCatalog(); const category = { id: id(), name: name.trim(), order: categories.length }; categories.push(category); await persistCatalog(); return category; }
export async function updateCategory(categoryId: string, name: string) { await ensureCatalog(); const item = categories.find(c => c.id === categoryId); if (!item) return null; item.name = name; await persistCatalog(); return item; }
export async function deleteCategory(categoryId: string) { await ensureCatalog(); const index = categories.findIndex(c => c.id === categoryId); if (index <= 0) return false; categories.splice(index, 1); await persistCatalog(); return true; }
